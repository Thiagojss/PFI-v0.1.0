# PFI v0.1.0
Aplicação local de gestão patrimonial. Python 3.10+; Windows: extraia o ZIP e execute iniciar.bat. Abra http://127.0.0.1:8000. Linux/macOS: python3 -m venv .venv; source .venv/bin/activate; pip install -r requirements.txt; python -m uvicorn main:app --host 127.0.0.1 --port 8000. API documentada em /docs.

Dados iniciais informados: R$ 50.000 na Caixa, R$ 5.211 de parcelas nominais restantes, despesas R$ 1.000 e meta líquida R$ 100.000. Confirme os saldos. A carteira-alvo é apenas planejamento. Movimentações não alteram saldos automaticamente: atualize os saldos manualmente. Não há integração bancária, cotações ao vivo, IA, execução de ordens ou cálculo tributário nesta versão.

O banco data/pfi.db é criado na primeira execução. Faça backup pela interface. Para restaurar, encerre o servidor, preserve uma cópia do banco atual e substitua data/pfi.db pelo backup. Não exponha a porta à internet. Não há autenticação nem criptografia; use apenas em computador pessoal confiável. Dependências exigem internet na instalação; uso normal offline. Não publique dados pessoais em GitHub.

Testes: python -m unittest discover -s tests. Valores monetários armazenados em centavos inteiros. Projeções são hipotéticas, nominais e usam taxa anual efetiva convertida para mensal.

## v0.2.0 — atualização
Feche o servidor anterior. Faça uma cópia integral da pasta PFI (incluindo data/pfi.db) em local privado. Extraia o ZIP sobre a pasta anterior, substituindo somente os arquivos de código; não exclua data/ nem o banco. O ZIP não contém banco. Execute iniciar.bat. Na primeira abertura a migração aditiva cria backup pfi-pre-v02-*.db em data/.

- Histórico: confira saldos e registre a posição do dia; não é reconstruído retroativamente.
- Parcelas: configure valor e quantidade restantes conforme extrato. Registrar pagamento reduz apenas dívida nominal; atualize o saldo bancário e registre despesa separadamente. Não é uma ordem bancária. Não inclui cálculo de desconto por antecipação.
- Relatórios: escolha mês, categorize movimentos e exporte CSV. Aportes/resgates são separados do saldo de receitas menos despesas.
- Dados permanecem locais e sem criptografia; não exponha o servidor.
- Testes: instale httpx e execute `python -m unittest discover -s tests -v` usando PFI_DB apontando para um banco temporário. Nunca use o banco pessoal para testes.
